$(document).ready(function(){
  $(".hide").hide();
  
  
  $(".marker-sixth").click(function(){
    $(".hide").hide();
    $(".sixth-txt").fadeIn(300);
  });
  
    $(".marker-seventh").click(function(){
       $(".hide").hide();
    $(".seventh-txt").fadeIn(300);
  });
  
    $(".marker-loisaida").click(function(){
       $(".hide").hide();
    $(".loisaida-txt").fadeIn(300);
  });
  
});